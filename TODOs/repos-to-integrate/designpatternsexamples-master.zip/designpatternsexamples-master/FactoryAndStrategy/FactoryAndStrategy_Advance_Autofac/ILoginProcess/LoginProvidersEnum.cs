﻿namespace FactoryAndStrategyAutofac.ILoginProcess
{
    public enum LoginProvidersEnum
    {
        Facebook,
        Google,
        Microsoft
    }
}
