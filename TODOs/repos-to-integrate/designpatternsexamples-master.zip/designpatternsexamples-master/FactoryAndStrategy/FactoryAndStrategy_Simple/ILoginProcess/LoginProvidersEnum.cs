﻿namespace FactoryAndStrategy.ILoginProcess
{
    public enum LoginProvidersEnum
    {
        Facebook,
        Google,
        Microsoft
    }
}
