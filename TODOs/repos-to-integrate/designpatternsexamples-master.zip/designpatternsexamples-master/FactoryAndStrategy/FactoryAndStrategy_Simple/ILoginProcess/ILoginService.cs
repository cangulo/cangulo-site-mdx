﻿namespace FactoryAndStrategy
{
    public interface ILoginService
    {
        bool Login(string username, string password);
    }
}
