﻿namespace FactoryAndStrategyByVersionAutofac.Validators
{
    public interface IVersionHandler
    {
        int GetVersion();
    }

}
