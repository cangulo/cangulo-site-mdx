﻿using log4net;
using MoviesManager.Common;
using MoviesManager.Model.DB;

namespace MoviesManager.Services.MovieService
{
    public class MovieServiceLogDecorator : IMovieService
    {
        private readonly IMovieService _serviceDecorate;
        private readonly ILog _logger;
        public MovieServiceLogDecorator(ILog logger, IMovieService serviceDecorate)
        {
            this._serviceDecorate = serviceDecorate;
            this._logger = logger;

        }

        public Result GetMovies()
        {
            Result resultService = this._serviceDecorate.GetMovies();
            this._logger.Info($"movies loaded corretly {resultService.Success}");
            if (!resultService.Success)
            {
                this._logger.Error((resultService as FailedResult).Errors);
            }
            return resultService;
        }

        public Result RegisterMovie(Movie movie)
        {
            Result resultService = this._serviceDecorate.GetMovies();
            this._logger.Info($"movie registered correctly {resultService.Success}");
            if (!resultService.Success)
            {
                this._logger.Error((resultService as FailedResult).Errors);
            }
            return resultService;
        }
    }
}
