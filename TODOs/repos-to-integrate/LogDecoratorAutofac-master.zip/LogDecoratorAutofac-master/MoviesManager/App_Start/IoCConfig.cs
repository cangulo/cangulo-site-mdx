﻿using Autofac;
using Autofac.Integration.WebApi;
using log4net;
using MoviesManager.Repositories.MovieRepository;
using MoviesManager.Services.MovieService;
using System;
using System.Reflection;
using System.Web.Http;

namespace MoviesManager.App_Start
{
    public class IoCConfig
    {
        public static void Configure()
        {
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            // log4net
            builder.Register(c => LogManager.GetLogger(typeof(Object))).As<ILog>();

            // Services
            builder.RegisterType<MovieService>().Named<IMovieService>("MovieService");
            builder.RegisterType<MovieRepository>().As<IMovieRepository>();

            // Decorators
            builder.RegisterDecorator<IMovieService>((ctx, inner)
                => new MovieServiceLogDecorator(ctx.Resolve<ILog>(), inner), "MovieService");
            
            var container = builder.Build();
            var resolver = new AutofacWebApiDependencyResolver(container);
            GlobalConfiguration.Configuration.DependencyResolver = resolver;
        }
    }
}