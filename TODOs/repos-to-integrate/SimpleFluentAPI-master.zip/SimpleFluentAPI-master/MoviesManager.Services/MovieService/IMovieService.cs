﻿using MoviesManager.Common;
using MoviesManager.Model.DB;

namespace MoviesManager.Services.MovieService
{
    public interface IMovieService
    {
        Result GetMovies();

        Result RegisterMovie(Movie movie);
    }
}
