﻿namespace MoviesManager.Common
{
    public abstract class Result
    {
        public bool Success { get; }
        public Result(bool success)
        {
            this.Success = success;
        }
    }
}
