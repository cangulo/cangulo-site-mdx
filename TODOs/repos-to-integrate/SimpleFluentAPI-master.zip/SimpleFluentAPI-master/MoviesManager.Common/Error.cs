﻿using System;

namespace MoviesManager.Common
{
    public class Error : Exception
    {
        public Error(string errorMessage, string errorCode, string errorLayer)
        {
            this.ErrorCode = errorCode;
            this.ErrorMesssage = errorMessage;
            this.ErrorLayer = errorLayer;
        }

        public Error(Exception ex, string errorLayer)
        {
            this.ErrorCode = "Exception";
            this.ErrorMesssage = ex.Message;
            this.ErrorLayer = errorLayer;
            this.Exception = ex;
        }
        public string ErrorMesssage { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorLayer { get; set; }

        public Exception Exception { get; set; }

        public override string ToString()
        {
            string customErrorMessage = $"ErrorCode: {this.ErrorCode}; ErrorMessage: {this.ErrorMesssage}; ErrorLayer: {this.ErrorLayer}; Excetion: ";
            if (this.Exception != null)
            {
                customErrorMessage += this.Exception.ToString();
            }

            return customErrorMessage;
        }
    }
}
