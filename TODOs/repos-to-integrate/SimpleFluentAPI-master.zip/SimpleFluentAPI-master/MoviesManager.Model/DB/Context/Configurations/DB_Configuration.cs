﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.SqlServer;

namespace MoviesManager.Model.DB.Context.Configurations
{
    public class DB_Configuration : DbConfiguration
    {
        public DB_Configuration()
        {
            SetProviderServices("System.Data.SqlClient", SqlProviderServices.Instance);
            SetDefaultConnectionFactory(connectionFactory: new SqlConnectionFactory());
        }

    }
}
