﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MoviesManager.Model.DB.Context.Configuration
{
    public class MovieConfiguration : EntityTypeConfiguration<Movie>
    {
        public MovieConfiguration()
        {
            ToTable("Movies");
            HasKey(x => x.MovieId);
            Property(x => x.MovieId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).HasColumnName("Id");
            Property(x => x.Title).IsRequired();
            Property(x => x.Director).IsRequired();
            Property(x => x.Year).IsRequired();
        }
    }
}
