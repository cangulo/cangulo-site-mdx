﻿using MoviesManager.Model.Migrations;
using System.Data.Entity;

namespace MoviesManager.Model.DB.Context
{
    public static class DBStartupManager
    {
        public static void StartDB()
        {
            Database.SetInitializer<MoviesManagerDBContext>(null);

            DBMigrationsManager.MigrateDB();

            using (var database = new MoviesManagerDBContext())
            {
                database.Database.Initialize(false);
            }

        }
    }
}
