﻿using MoviesManager.Model.DB.Context.Configuration;
using System.Data.Entity;

namespace MoviesManager.Model.DB.Context
{
    public class MoviesManagerDBContext : DbContext
    {
        public MoviesManagerDBContext() : base("MoviesManagerDB")
        {
            
        }

        public DbSet<Movie> Movies { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("dbo");
            modelBuilder.Configurations.Add(new MovieConfiguration());
            base.OnModelCreating(modelBuilder); 
        }
    }
}
