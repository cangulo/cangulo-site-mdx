﻿using log4net;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;

namespace MoviesManager.Model.Migrations
{
    public static class DBMigrationsManager
    {
        private static readonly ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static void MigrateDB()
        {
            var migrator = new DbMigrator(new DBMigrationsGeneralConfiguration());

            List<string> pendingMigrations = migrator.GetPendingMigrations().OrderBy(x => x).ToList();

            try
            {
                if (pendingMigrations.Any())
                {
                    log.Info($"There are {pendingMigrations.Count} pending db migrations");
                    foreach (var migration in pendingMigrations)
                    {
                        log.Info($"{migration} been executed");
                        migrator.Update(migration);
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error("Unable to migrate database. Not compatible.", ex);
                throw ex;
            }

        }
    }
}
