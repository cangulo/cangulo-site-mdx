- [Using CopyQ as a Clipboard Manager in Linux](#using-copyq-as-a-clipboard-manager-in-linux)
  - [Problem](#problem)
  - [Solution: Clipboard Manager, CopyQ](#solution-clipboard-manager-copyq)
  - [About me](#about-me)
  - [References](#references)

# Using CopyQ as a Clipboard Manager in Linux

The next post is focus on Linux users; in my case, I use [Elementary OS](https://elementary.io). 
For Windows 10 users, a  default clipboard manager is included from 2018, but you should activate it in the settings,  to do it please follow this [link](https://www.windowscentral.com/how-use-new-clipboard-windows-10-october-2018-update).

## Problem

Sometimes in the terminal, coding, or browsing the internet we copy and paste text several times, let's imagine the next scenario:

1. I open a web page, copy a piece of text with the word `arepa con queso` (google it, it's delicious!).
2. I perform any operations in the terminal with the name `arepa con queso`.
3. I copy another text as `ceviche de mariscos` (also delicious!).).
4. I perform any other operations with that.
5. If I have to use again the word `arepa con queso`, I would have to come back to the web page `1.`, select the text and copy it again. Let's see how to avoid that.

## Solution: Clipboard Manager, CopyQ

A clipboard manager offers you a history, where you quickly can select any previous copied word, I recommend [CopyQ ](https://hluk.github.io/CopyQ/) because it is easy to use and configure. It works as following:

![Use Clipboard Manager](resources/use_clipboard_manager.gif)

As you see, once the CopyQ window is prompt you only have to navigate to the entry you want to paste, you can use the keyboard arrows up or down, and press `Enter` to paste it wherever you had the cursor before. 
My advice is to configure a keyboard shortcut as `Crl + Shift + v` or `Windows + v` to prompt the main windows. The steps are next:

![Configure CopyQ Keyboard Shortcut](resources/configure_copyq_keyboar_shortcut.gif)

On the other hand, I also recommend you to clean your history if you have copied any sensitive information as password or tokens and limit the number of items to be stored. I limit mine to 10:

![Configure CopyQ Keyboard Shortcut](resources/configure_copyq_items_to_store.png)

I hope this helps you to be more productive when using Linux!

## About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
      <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

## References

[Official CopyQ Github](https://hluk.github.io/CopyQ/)

[Official CopyQ Documentation](https://copyq.readthedocs.io/en/latest/)

[Clipboard Manager Alternatives](https://www.tecmint.com/best-clipboard-managers-for-linux/)

<p align="right">
    <a href="#">Come back to the top</a>
</p>