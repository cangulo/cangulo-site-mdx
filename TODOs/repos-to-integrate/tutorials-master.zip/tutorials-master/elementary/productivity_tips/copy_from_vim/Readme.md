<!-- TODO:Complete This article -->
<!-- TODO:How to open vim ? -->
<!-- TODO:How to copy a line from vim? -->