# How to configure Git Credentials in VSCode using libsecret as Git Credentials Helper

<!-- TODO: Verify this article -->
<!-- TODO: Publish -->

# Problem

When you are using VSCode in Ubuntu, in my case Elementary, each time you push changes to your repository, you have to provide user and password as follows:

![VSCode Git Authentication](./authentication_git_vscode.gif)

# Solution

Setup a credential helper for git, I tried the library  **libsecret**, but there are other [options](https://www.softwaredeveloper.blog/git-credential-storage-libsecret). Next are the steps:

1. Install the library: 

```bash
sudo apt-get install libsecret-1-0 libsecret-1-dev
```

2. Go to /usr/share/doc/git/contrib/credential/gnome-keyring

```bash
cd /usr/share/doc/git/contrib/credential/libsecret
```

3. Compile the package:

```bash
sudo make
```

4. Modify the global git configuration as following:

```bash
git config --global credential.helper /usr/share/doc/git/contrib/credential/libsecret/git-credential-libsecret
```

From now on, next time you push will be the last one you have to provide the credentials.

I hope this helps you!

## About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
      <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

# References

https://stackoverflow.com/questions/36585496/error-when-using-git-credential-helper-with-gnome-keyring-as-sudo/40312117#40312117

https://www.softwaredeveloper.blog/git-credential-storage-libsecret
https://wiki.archlinux.org/index.php/GNOME/Keyring

If you prefer to use ssh keys:
https://www.softwaredeveloper.blog/store-git-ssh-credentials-in-linux

<p align="right">
      <a href="#">Come back to the top</a>
</p>