﻿using MoviesManager.Common;
using MoviesManager.Model.BE;
using MoviesManager.Repositories.MovieRepository;

namespace MoviesManager.Services.MovieService
{
    public class MovieService : IMovieService
    {
        private IMovieRepository _movieRepo;
        public MovieService(IMovieRepository movieRepo)
        {
            this._movieRepo = movieRepo;
        }
        public Result GetMovies()
        {
            bool serviceValidation = true;
            if (serviceValidation)
            {
                Result getMoviesResult = this._movieRepo.GetMovies();
                if (getMoviesResult.Success)
                {
                    return getMoviesResult;
                }
                else
                {
                    return new FailedResult("Error from the repository", "2", "Services", (getMoviesResult as FailedResult).Errors);
                }
            }
            else
            {
                return new FailedResult("Error from the service", "1", "Services");
            }
        }

        public Result RegisterMovie(Movie movie)
        {
            bool serviceLayerValidation = true;
            if (serviceLayerValidation)
            {
                Result registerMovieResult = this._movieRepo.RegisterMovie(movie);
                if (registerMovieResult.Success)
                {
                    return registerMovieResult;
                }
                else
                {
                    return new FailedResult("Error from the repository", "2", "Services", (registerMovieResult as FailedResult).Errors);
                }
            }
            else
            {
                return new FailedResult("Movie information is not valid", "1", "Services");
            }
        }
    }
}
