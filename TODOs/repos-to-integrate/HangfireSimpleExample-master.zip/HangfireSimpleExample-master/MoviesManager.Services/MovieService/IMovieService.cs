﻿using MoviesManager.Common;
using MoviesManager.Model.BE;

namespace MoviesManager.Services.MovieService
{
    public interface IMovieService
    {
        Result GetMovies();

        Result RegisterMovie(Movie movie);
    }
}
