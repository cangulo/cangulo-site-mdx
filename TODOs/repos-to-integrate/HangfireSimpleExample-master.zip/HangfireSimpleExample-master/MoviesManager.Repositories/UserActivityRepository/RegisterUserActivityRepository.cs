﻿using log4net;
using MoviesManager.Model.BE;
using MoviesManager.Model.DB.Context;
using System;

namespace MoviesManager.Repositories.UserActivityRepository
{
    public class RegisterUserActivityRepository : IRegisterUserActivityRepository
    {
        private static readonly ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public void RegisterUserActivity(UserActivity userActivity)
        {
            try
            {
                using (var moviesDatabaseContext = new MoviesManagerDBContext())
                {
                    moviesDatabaseContext.UserActivity.Add(userActivity);
                    moviesDatabaseContext.SaveChanges();
                }
                log.Info($"RegisterUserActivity registered correctly for the user {userActivity.UserId} action: {userActivity.Action}");
            }
            catch (Exception e)
            {
                log.Error(e);
            }
        }
    }
}
