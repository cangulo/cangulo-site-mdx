﻿using MoviesManager.Common;
using MoviesManager.Model.BE;

namespace MoviesManager.Repositories.UserActivityRepository
{
    public interface IRegisterUserActivityRepository
    {
        void RegisterUserActivity(UserActivity userActivity);
    }
}
