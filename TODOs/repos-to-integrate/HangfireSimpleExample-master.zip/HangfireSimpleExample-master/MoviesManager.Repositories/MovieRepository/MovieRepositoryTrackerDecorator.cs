﻿using MoviesManager.BackgroundTasks.BackgroundJobs;
using MoviesManager.Common;
using MoviesManager.Model.BE;
using MoviesManager.Repositories.UserActivityRepository;
using System;

namespace MoviesManager.Repositories.MovieRepository
{
    public class MovieRepositoryTrackerDecorator : IMovieRepository
    {
        private IMovieRepository _movieRepository;
        private IRegisterUserActivityRepository _userActivityRepository;
        private IBackgroundJobService _backgroundJob;
        public MovieRepositoryTrackerDecorator(IMovieRepository movieRepository, IRegisterUserActivityRepository userActivityRepository, IBackgroundJobService backgroundJobService)
        {
            _movieRepository = movieRepository;
            _userActivityRepository = userActivityRepository;
            _backgroundJob = backgroundJobService;
        }
        public Result GetMovies()
        {
            Result resultGetMovies = _movieRepository.GetMovies();
            if (resultGetMovies.Success)
            {
                _backgroundJob.EnqueueTask(() =>
                    _userActivityRepository.RegisterUserActivity(
                        new UserActivity()
                        {
                            UserId = 1,
                            Action = "GetMovies",
                            Time = DateTime.UtcNow
                        })
                );
            }
            return resultGetMovies;
        }

        public Result RegisterMovie(Movie movie)
        {
            Result resultRegisterMovie = _movieRepository.RegisterMovie(movie);
            if (resultRegisterMovie.Success)
            {
                this._backgroundJob.EnqueueTask(() =>
                    _userActivityRepository.RegisterUserActivity(
                        new UserActivity()
                        {
                            UserId = 1,
                            Action = "RegisterMovie",
                            Time = DateTime.UtcNow
                        })
                );

            }
            return resultRegisterMovie;
        }
    }
}
