﻿using MoviesManager.Common;
using MoviesManager.Model.BE;
using MoviesManager.Model.DB.Context;
using System.Collections.Generic;
using System.Linq;

namespace MoviesManager.Repositories.MovieRepository
{
    public class MovieRepository : IMovieRepository
    {
        public Result GetMovies()
        {

            bool queryValidation = true;
            if (queryValidation)
            {
                using (var moviesDatabaseContext = new MoviesManagerDBContext())
                {
                    return new SuccessResult<List<Movie>>(moviesDatabaseContext.Movies.ToList<Movie>());
                };
            }
            else
            {
                return new FailedResult("Error in the query", "1", "Repository");
            }
        }

        public Result RegisterMovie(Movie movie)
        {
            bool movieDataValidation = true;
            if (!movieDataValidation)
            {
                return new FailedResult("Director is not valid", "1", "Repository");
            }
            else
            {
                using (var moviesDatabaseContext = new MoviesManagerDBContext())
                {
                    moviesDatabaseContext.Movies.Add(movie);
                    moviesDatabaseContext.SaveChanges();
                    return new SuccessResult();
                };
            }
        }
    }
}
