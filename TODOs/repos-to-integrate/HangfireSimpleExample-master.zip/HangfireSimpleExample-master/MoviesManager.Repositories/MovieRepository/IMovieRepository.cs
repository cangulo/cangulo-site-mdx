﻿using MoviesManager.Common;
using MoviesManager.Model.BE;

namespace MoviesManager.Repositories.MovieRepository
{
    public interface IMovieRepository
    {
        Result GetMovies();

        Result RegisterMovie(Movie movie);
    }
}
