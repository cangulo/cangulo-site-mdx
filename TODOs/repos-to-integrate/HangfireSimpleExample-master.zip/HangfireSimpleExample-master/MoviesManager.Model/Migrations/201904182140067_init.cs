namespace MoviesManager.Model.Migrations
{
    using log4net;
    using System.Data.Entity.Migrations;

    public partial class init : DbMigration
    {
        private static readonly ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override void Up()
        {
            log.Info($"AddUserActivityTable  - Up");
            CreateTable(
                "dbo.Movies",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false),
                        Director = c.String(nullable: false),
                        Year = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            log.Info($"AddUserActivityTable  - Down");
            DropTable("dbo.Movies");
        }
    }
}
