namespace MoviesManager.Model.Migrations
{
    using log4net;
    using System.Data.Entity.Migrations;

    public partial class AddUserActivityTable : DbMigration
    {
        private static readonly ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override void Up()
        {
            log.Info($"AddUserActivityTable  - Up");
            CreateTable(
                "dbo.UserActivity",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.Int(nullable: false),
                        Action = c.String(nullable: false),
                        Time = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            log.Info($"AddUserActivityTable  - Down");
            DropTable("dbo.UserActivity");
        }
    }
}
