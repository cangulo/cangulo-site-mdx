﻿using log4net;
using MoviesManager.Model.BE;
using MoviesManager.Model.DB.Context;
using System.Data.Entity.Migrations;
using System.Linq;

namespace MoviesManager.Model.Migrations
{
    internal sealed class DBMigrationsGeneralConfiguration : DbMigrationsConfiguration<MoviesManagerDBContext>
    {
        private static readonly ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public DBMigrationsGeneralConfiguration()
        {
            log.Info($"Starting DB model");
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(DB.Context.MoviesManagerDBContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            if (context.Movies.Count() == 0)
            {
                context.Movies.AddRange(
                    new Movie[]{
                        new Movie(){
                            Title = "Star Wars: Episode IV - A New Hope",
                            Director = "George Lucas",
                            Year = 1977
                        },
                        new Movie(){
                            Title = "Star Wars: Episode V - The Empire Strikes Back",
                            Director = "George Lucas",
                            Year = 1980
                        }
                    });
                context.SaveChanges();
            }
        }
    }
}
