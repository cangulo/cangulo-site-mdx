﻿using System;

namespace MoviesManager.Model.BE
{
    public class UserActivity
    {
        public int UserActivityId { get; set; }
        public int UserId { get; set; }
        public string Action { get; set; }
        public DateTime Time { get; set; }
    }
}
