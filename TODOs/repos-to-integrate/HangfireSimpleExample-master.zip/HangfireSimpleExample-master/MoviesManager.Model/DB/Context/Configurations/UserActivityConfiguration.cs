﻿using MoviesManager.Model.BE;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MoviesManager.Model.DB.Context.Configuration
{
    public class UserActivityConfiguration : EntityTypeConfiguration<UserActivity>
    {
        public UserActivityConfiguration()
        {
            ToTable("UserActivity");
            HasKey(x => x.UserActivityId);
            Property(x => x.UserActivityId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity).HasColumnName("Id");
            Property(x => x.UserId).IsRequired();
            Property(x => x.Action).IsRequired();
            Property(x => x.Time).IsRequired();
        }
    }
}
