﻿using MoviesManager.Model.BE;
using MoviesManager.Model.DB.Context.Configuration;
using System.Data.Entity;

namespace MoviesManager.Model.DB.Context
{
    public class MoviesManagerDBContext : DbContext
    {
        public MoviesManagerDBContext() : base("MoviesManagerDB") {}

        public DbSet<Movie> Movies { get; set; }
        public DbSet<UserActivity> UserActivity { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("dbo");
            modelBuilder.Configurations.Add(new MovieConfiguration());
            modelBuilder.Configurations.Add(new UserActivityConfiguration());
            base.OnModelCreating(modelBuilder);
        }
    }
}
