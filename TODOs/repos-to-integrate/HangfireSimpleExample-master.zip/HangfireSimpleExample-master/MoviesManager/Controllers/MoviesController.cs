﻿using MoviesManager.Common;
using MoviesManager.Model.BE;
using MoviesManager.Services.MovieService;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;

namespace MoviesManager.Controllers
{
    public class MoviesController : ApiController
    {
        private readonly IMovieService _movieService;
        public MoviesController(IMovieService movieService)
        {
            this._movieService = movieService;
        }
        public IHttpActionResult Get()
        {
            Result resultMovies =  this._movieService.GetMovies();
            if (resultMovies.Success)
            {
                return Ok((resultMovies as SuccessResult<List<Movie>>).Value);
            }
            else
            {
                return Content((HttpStatusCode.BadRequest), (resultMovies as FailedResult).Errors);
            }
            
        }

        [HttpPost]
        public IHttpActionResult PostMovie([FromBody]Movie movie)
        {
            Result registerMovierResult = this._movieService.RegisterMovie(movie);
            if (registerMovierResult.Success)
            {
                return Ok();
            }
            else
            {
                return Content((HttpStatusCode.BadRequest), (registerMovierResult as FailedResult).Errors);
            }
        }


    }
}
