﻿using Microsoft.Owin;
using MoviesManager.BackgroundTasks;
using Owin;

[assembly: OwinStartup(typeof(MoviesManager.App_Start.MoviesManagerStartup))]

namespace MoviesManager.App_Start
{
    public class MoviesManagerStartup
    {
        public void Configuration(IAppBuilder app)
        {
            // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=316888
            (new ConfigureHangfire()).Configure(app);
            
        }
    }
}
