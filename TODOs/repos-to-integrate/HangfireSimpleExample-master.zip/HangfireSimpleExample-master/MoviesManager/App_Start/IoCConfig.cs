﻿using Autofac;
using Autofac.Integration.WebApi;
using log4net;
using MoviesManager.BackgroundTasks.BackgroundJobs;
using MoviesManager.Repositories.MovieRepository;
using MoviesManager.Repositories.UserActivityRepository;
using MoviesManager.Services.MovieService;
using System;
using System.Reflection;
using System.Web.Http;

namespace MoviesManager.App_Start
{
    public class IoCConfig
    {
        public static void Configure()
        {
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            // log4net
            builder.Register(c => LogManager.GetLogger(typeof(Object))).As<ILog>();

            // Services
            builder.RegisterType<MovieService>().Named<IMovieService>("MovieService");
            // Repository
            builder.RegisterType<MovieRepository>().Named<IMovieRepository>("MovieRepository");
            builder.RegisterType<RegisterUserActivityRepository>().As<IRegisterUserActivityRepository>();
            // Jobs Services
            builder.RegisterType<BackgroundJobService>().As<IBackgroundJobService>();

            // Decorators
            builder.RegisterDecorator<IMovieService>((ctx, inner)
                => new MovieServiceLogDecorator(inner, ctx.Resolve<ILog>()), "MovieService");
            builder.RegisterDecorator<IMovieRepository>((ctx, inner)
                => new MovieRepositoryTrackerDecorator(inner, ctx.Resolve<IRegisterUserActivityRepository>(), ctx.Resolve<IBackgroundJobService>()), "MovieRepository");

            var container = builder.Build();
            var resolver = new AutofacWebApiDependencyResolver(container);
            GlobalConfiguration.Configuration.DependencyResolver = resolver;
        }
    }
}