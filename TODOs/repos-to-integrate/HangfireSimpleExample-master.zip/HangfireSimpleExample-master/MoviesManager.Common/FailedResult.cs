﻿using System.Collections.Generic;
using System.Linq;

namespace MoviesManager.Common
{
    public class FailedResult : Result
    {
        public FailedResult(Error error) : base(false)
        {
            this.Errors = new Error[1] { error };
        }

        public FailedResult(string errorMessage, string errorCode, string errorLayer) : base(false)
        {
            Error error = new Error(errorMessage, errorCode, errorLayer);
            this.Errors = new Error[1] { error };
        }
        public FailedResult(string errorMessage, string errorCode, string errorLayer, IEnumerable<Error> errors) : base(false)
        {
            Error lastError = new Error(errorMessage, errorCode, errorLayer);
            this.Errors = errors.Concat(new Error[] { lastError });
        }

        public IEnumerable<Error> Errors { get; set; }
    }
}
