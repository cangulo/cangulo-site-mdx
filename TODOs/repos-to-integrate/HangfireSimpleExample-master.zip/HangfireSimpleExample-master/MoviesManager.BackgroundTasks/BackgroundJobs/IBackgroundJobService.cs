﻿using System;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace MoviesManager.BackgroundTasks.BackgroundJobs
{
    public interface IBackgroundJobService
    {
        void EnqueueTask(Expression<Action> methodCall);
        void EnqueueTask(Expression<Func<Task>> methodCall);
        void EnqueueTask<T>(Expression<Func<T, Task>> methodCall);
        void EnqueueTask<T>(Expression<Action<T>> methodCall);
    }
}
