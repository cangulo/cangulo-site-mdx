﻿using System;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace MoviesManager.BackgroundTasks.BackgroundJobs
{
    public class BackgroundJobService : IBackgroundJobService
    {
        public void EnqueueTask(Expression<Action> methodCall)
        {
            Hangfire.BackgroundJob.Enqueue(methodCall);
        }

        public void EnqueueTask(Expression<Func<Task>> methodCall)
        {
            Hangfire.BackgroundJob.Enqueue(methodCall);
        }

        public void EnqueueTask<T>(Expression<Func<T, Task>> methodCall)
        {
            Hangfire.BackgroundJob.Enqueue<T>(methodCall);
        }

        public void EnqueueTask<T>(Expression<Action<T>> methodCall)
        {
            Hangfire.BackgroundJob.Enqueue<T>(methodCall);
        }
    }
}
