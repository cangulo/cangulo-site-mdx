- [Git CheatSheet](#git-cheatsheet)
  - [Git Commands](#git-commands)
  - [How to configure an Alias](#how-to-configure-an-alias)
  - [Alias configured](#alias-configured)
  - [Githooks](#githooks)
    - [Problem](#problem)
    - [Solution](#solution)
    - [Example Pre Commit file example](#example-pre-commit-file-example)
  - [About me](#about-me)
  - [References](#references)

# Git CheatSheet

## Git Commands

| command                              | description1                                     |
| ------------------------------------ | ------------------------------------------------ |
| `$ git checkout --track origin/NAME` | create a local branch that tracks the remote one |

## How to configure an Alias

1. Open your `.gitconfigure` file, it is located at your home folder
2. In a new line, add the tag `[alias]`
3. In the next lines add your alias following the format `AliasName=AliasValue`. e.g. `co=checkout`

<!-- ## Advanced Alias -->

<!-- You can define alias that receives parameters as next -->
<!-- TODO: Explain -->

## Alias configured

<!-- CODE_START ./resources/git-alias bash -->
```bash
[alias]
	b = branch
	bd = branch -D
	co = checkout
	cob = checkout -b
	cor = checkout --track
	cp = cherry-pick
	cp-c = cherry-pick --continue
	cp-a = cherry-pick --abort
	re = rebase -i
	re-a = rebase --abort
	st = status
	l = "!f() { git log --oneline -n ${1-15}; }; f"
	lg = "!f() { git log --oneline --grep=${1-No Argument Provided}; }; f"
	settings = config --global --edit
```
<!-- CODE_END -->

## Githooks
<!-- TODO: Define an article and create in tutorials -->
<!-- TODO: Define a cheatsheet here -->

### Problem

Perform actions before or after any commit, let's say, automatize actions following the git workflow. \
In my case, I want to make sure that all my markdown files has any code reference updated. For that, I execute a bash file called `update_sh_code_in_md_files.sh`.

### Solution

Create a githook that is executed before doing a commit.


By default, git create the next set of samples in  `.git/hooks`.

```bash
applypatch-msg.sample
commit-msg.sample
fsmonitor-watchman.sample
post-update.sample
pre-applypatch.sample
pre-commit.sample
prepare-commit-msg.sample
pre-push.sample
pre-rebase.sample
pre-receive.sample
update.sample
```

If a common policy for pre-commit needs to be updated to the repository the `pre-commit` should be located outside the `.git` folder, this will ensure the folder will be tracked in git. Then, we have to configure git to use that path as the source for hooks, this could be done as next:

```bash
git config --local core.hooksPath ./githooks
```

In case we want to set a global policy, it could be done with the same command but adding `--global` as parameter. In my case, all my repositories contains markdown files with reference to code that I want to update 


```bash
git config --global core.hooksPath ./githooks
```

If the hook is set as *global* the configuration file modified will be  `.gitconfig `, at the home user directory. \
On the other hand, if it is *local*, the file modified will be `.config` in  the `.git` folder of the repository.

Next are the lines to be added in the file:
<!-- CODE_START ./resources/githooks/gitconfig-with-hooks bash -->
```bash
[core]
	hooksPath = /home/carlos/Documents/github_repositories/cheatsheet/GitCheatsheet/resources/githooks/
```
<!-- CODE_END -->



### Example Pre Commit file example
<!-- TODO: Get the list of files to be modified and add them to the commit as follow -->
<!-- to avoid have them as separate (second) commit when modified -->
<!-- git add /home/carlos/Documents/github_repositories/cheatsheet/BashCheatSheet/BashCheatSheet.md -->

<!-- CODE_START ./resources/githooks/pre-commit bash -->
```bash
#!/bin/sh

echo "### PRE-COMMIT GLOBAL PROCESS"

/home/carlos/Documents/github_repositories/bashScripts/markdown_helpers/update_code_in_docs/update_sh_code_in_md_files.sh
executionResult=$?

if [ $executionResult -eq 0 ]; then
    echo "###      RESULT OK"
else
    echo "###      RESULT NOT OK"
fi

echo "### PRE-COMMIT GLOBAL PROCESS END"
exit $executionResult
```
<!-- CODE_END -->

<p align="center">
  <a href="./resources/githooks/pre-commit"><i>pre-commit file</i></a>
</p>

## About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
    <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

 ## References

[githooks official docs](https://git-scm.com/docs/githooks)  
[How do I modify my Git Bash profile in Windows?](https://superuser.com/questions/602872/how-do-i-modify-my-git-bash-profile-in-windows)  
 
<!-- TODO: https://kurtdowswell.com/software-development/git-bash-aliases/  -->
<!-- TODO: https://jondavidjohn.com/git-aliases-parameters/  -->

<p align="right">
    <a href="#">Come back to the top</a>
</p>