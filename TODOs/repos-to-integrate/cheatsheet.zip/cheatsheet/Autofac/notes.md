# Notes

## Steps Done

1. Execute next command lines

    dotnet tool install --global dotnet-try
    dotnet tool update -g dotnet-try


# Summary

dotnet try verify [Path] -> Compila
dotnet try [Path] -> Create la web local

path not required if the .csproj is in a Subfolder

# Main notes 

If you want to execute code before or after an specific region you can do next:
1. Define a hidden code call before and reference the region 
2. Create a 