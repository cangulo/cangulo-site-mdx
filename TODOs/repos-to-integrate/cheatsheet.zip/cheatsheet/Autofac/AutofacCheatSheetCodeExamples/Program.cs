﻿using Autofac;
using AutofacCheatSheetCodeExamples.Services;
using System;

namespace AutofacCheatSheetCodeExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            #region AutofacExecution
            using (var scope = RegisterDependenciesAutofac().BeginLifetimeScope())
            {
                var serviceImplementation = scope.Resolve<IService>();
                var result = serviceImplementation.ServiceAction1("test");

                if (result)
                    Console.WriteLine("Result Success");
            }
            #endregion
        }


        /// <summary>
        /// Autofac DI 
        /// </summary>
        /// <returns></returns>
        private static IContainer RegisterDependenciesAutofac()
        {
            var builder = new ContainerBuilder();

            builder.RegisterModule(new AutofacModuleExample());

            return builder.Build();
        }
    }
}
