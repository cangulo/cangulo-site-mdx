﻿using AutofacCheatSheetCodeExamples.Services;
using System;

namespace AutofacCheatSheetCodeExamples.Components
{
    /// <summary>
    /// This is consider a component
    /// </summary>
    /// <seealso cref="AutofacCheatSheetCodeExamples.Services.IService" />
    public class ServiceImplementation : IService
    {
        private readonly IRepository repository;

        public ServiceImplementation(IRepository repository)
        {
            this.repository = repository;
        }

        public bool ServiceAction1(string param1)
        {
            return repository.RepositoryAction1(param1);
        }
    }

    /// <summary>
    /// This is consider a component
    /// </summary>
    /// <seealso cref="AutofacCheatSheetCodeExamples.Services.IRepository" />
    public class RepositoryImplementation : IRepository
    {
        public bool RepositoryAction1(string param1)
        {
            return true;
        }
    }
}
