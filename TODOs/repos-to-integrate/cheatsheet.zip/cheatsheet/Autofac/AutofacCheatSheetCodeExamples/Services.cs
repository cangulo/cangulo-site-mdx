﻿namespace AutofacCheatSheetCodeExamples.Services
{
    public interface IService
    {
        bool ServiceAction1(string param1);
    }

    public interface IRepository
    {
        bool RepositoryAction1(string param1);
    }
}
