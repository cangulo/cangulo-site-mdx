﻿using Autofac;
using AutofacCheatSheetCodeExamples.Components;
using AutofacCheatSheetCodeExamples.Services;

namespace AutofacCheatSheetCodeExamples
{
    public class AutofacModuleExample : Module
    {
        // Register the classes associated to this Module
        protected override void Load(ContainerBuilder builder)
        {

            // Register the component RepositoryImplementation as the service IRepository
            #region BasicRegistration
            builder
                 .RegisterType<RepositoryImplementation>()
                 .As<IRepository>();
            #endregion

            builder
                 .RegisterType<ServiceImplementation>()
                 .As<IService>();

            base.Load(builder);
        }
    }
}
