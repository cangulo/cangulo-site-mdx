<!-- # Autofac Cheatsheet -->

<!-- ## Resolve Services  -->

<!-- ```csharp --source-file ./Program.cs --project ./AutofacCheatSheetCodeExamples.csproj --region AutofacExecution -->
<!-- ``` -->