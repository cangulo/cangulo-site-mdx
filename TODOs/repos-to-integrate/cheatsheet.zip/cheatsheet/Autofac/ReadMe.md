<!-- TODO: Progress in AutofactCheatSheet -->
<!-- TODO: Improve the bash code to also accept regions -->
<!-- # Autofac CheatSheet -->

<!-- ## Registration -->

