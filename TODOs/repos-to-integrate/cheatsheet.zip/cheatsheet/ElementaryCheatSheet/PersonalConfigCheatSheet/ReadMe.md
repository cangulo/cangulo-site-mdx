# Elementary Personal Config CheatSheet 

- [Elementary Personal Config CheatSheet](#elementary-personal-config-cheatsheet)
  - [Software installed](#software-installed)
  - [Custom Commands with Keyboard Shortcuts](#custom-commands-with-keyboard-shortcuts)
  - [Custom App Launchers](#custom-app-launchers)
  - [About me](#about-me)
  - [References](#references)

## Software installed

| Package         | Install Command / Cheatsheet                                                                                                                          | Utility                                                                                                                                                                   |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| code            | `sudo snap install code`                                                                                                                              | Install Visual Studio Code                                                                                                                                                |
| xclip           | `sudo apt install xclip`                                                                                                                              | Specific clipboard for the terminal                                                                                                                                       |
| Flameshot       | `sudo apt install flameshot`                                                                                                                          | Screenshot tool.[Official docs](https://github.com/lupoDharkael/flameshot). [Usage example](https://itsfoss.com/flameshot/)                                               |
| peek            | `sudo apt install software-properties-common`<br>`sudo add-apt-repository ppa:peek-developers/stable`<br>`sudo apt update`<br>`sudo apt install peek` | Application to record the screen as GIF. To improve the quality please check this [link](https://github.com/phw/peek#how-can-i-improve-the-quality-of-recorded-gif-files) |
| nano            | Usually installed by default. <br>`sudo apt install nano` <br>Nano [Cheatsheet](https://www.nano-editor.org/dist/latest/cheatsheet.html)              | Simple terminal text editor ([at least than vim](https://askubuntu.com/questions/726669/difference-between-nano-and-vim))                                                 |
| vim             | `sudo apt install vim` <br>[Vim Cheatsheet](https://vim.rtorr.com)                                                                                    | Advanced terminal text editor                                                                                                                                             |
| copyq           | `sudo apt install copyq`                                                                                                                              | Clipboard Manager for Elementary                                                                                                                                          |
| Telegram        | `sudo snap install telegram-desktop`                                                                                                                  | Simple image Editor                                                                                                                                                       |
| dconf UI editor | `sudo apt install dconf-editor`                                                                                                                       | Simple image Editor                                                                                                                                                       |
| blueman         | `sudo apt install blueman`                                                                                                                            | Simple image Editor                                                                                                                                                       |

<!-- ## Elementary keyboard shortcuts configured -->

<!-- ### Layout Config -->

<!-- ### Default Actions with custom keyboard shortcuts -->

## Custom Commands with Keyboard Shortcuts

| Keyboard Shortckut | Options                     | Remarks                                            |
| ------------------ | --------------------------- | -------------------------------------------------- |
| `Windows + i`      | `io.elementary.switchboard` | Open the `[File]` in the Text editor of Elementary |
| `Print`            | `frameshot gui`             | Activated the UI to do an screenshot               |
| `Ctrl + Print`     | `frameshot gui`             | Activated the UI to do an screenshot               |
| `Alt + Print`      | `peek`                      | Activated the UI to record a gif                   |
| `Windows q`        | `xkill`                     | The application clicked will be terminated         |
| `Windows v`        | `copyq menu`                | The application clicked will be terminated         |

<!-- TODO: Add new custom commands to open VS Code or Vivaldi, or switch between its windows -->

I described the process to set up those shortcuts [here](https://github.com/cangulo/tutorials/tree/master/elementary/configure_keyboard_shortcuts).

## Custom App Launchers


| Name                  | Description                                                                                        | link                                                                                                            |
| --------------------- | -------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| CheatSheet Repository | Open my personal cheatsheet repository folder in VS Code                                           | [vscode-repo-cheatsheet](./resources/customs_app_launchers/vs_code_repositories/vscode-repo-cheatsheet.desktop) |
| Tutorials Repository  | Open my personal Tutorials repository folder in VS Code                                            | [vscode-repo-tutorials](./resources/customs_app_launchers/vs_code_repositories/vscode-repo-tutorials.desktop)   |
| `Xkill`               | Activate the [`xkill`](https://www.howtoforge.com/tutorial/linux-kill-process-with-xkill/) command | [xkill](./resources/customs_app_launchers/system/xkill.desktop)                                                 |


<!--  TODO: ## Desktop configuration: Hot corners -->

<!-- * Get the hot corners configuration -->

<!-- ## Dock Settings -->
 
<!-- ```bash
plank --preferences
``` -->
## About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
    <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

## References

Why Do I install dconf-editor? To solve some keyboard problems as [this](https://elementaryos.stackexchange.com/questions/17974/volume-controls-on-function-keys-dont-work)

<p align="right">
  <a href="#">Come back to the top</a>
</p>

<!-- _PLANNING_: -->
<!-- 1. https://www.fosslinux.com/478/how-to-add-folders-and-group-apps-to-the-plank-in-elementary-os.htm -->
<!-- 2. https://www.fosslinux.com/26068/the-5-best-onenote-alternatives-for-linux.htm -->

<!-- TODO: Check next links -->
<!-- https://averagelinuxuser.com/after-install-elementary-juno/ -->
<!-- https://elementaryos.stackexchange.com/questions/1090/how-to-optimize-elementary-os-for-maximal-battery-life-time-on-laptops -->
<!-- https://blog.desdelinux.net/tlpui-una-excelente-interfaz-grafica-construida-en-gtk-para-tlp/ -->
<!-- https://github.com/d4nj1/TLPUI -->
<!-- https://vitux.com/improving-battery-life-in-ubuntu-with-tlp/ -->
<!-- https://wiki.archlinux.org/index.php/TLP -->
<!-- https://www.linuxmadesimple.info/2019/12/how-to-enable-dark-theme-on-elementary.html -->
<!-- https://github.com/elementary-tweaks/elementary-tweaks -->
<!-- https://www.linuxuprising.com/2020/04/how-to-cast-your-gnome-shell-desktop-to.html -->