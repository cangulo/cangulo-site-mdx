# Elementary CheatSheet 

- [Elementary CheatSheet](#elementary-cheatsheet)
  - [Elementary Basic Commands](#elementary-basic-commands)
  - [About me](#about-me)
  - [References](#references)


## Elementary Basic Commands

| Command                        | Options                          | Remarks                                                                                                                                                                                     |
| ------------------------------ | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `io.elementary.code`           | `io.elementary.code [File]`      | Open the `[File]` in the Text editor of Elementary                                                                                                                                          |
| `io.elementary.files`          | `io.elementary.files [Folder] &` | Open the Elementary Files Application in the  `[Folder]` <br>Please, note the `&` at the end for executing the command in the background, keeping the terminal available for other commands |
| `io.elementary.files`          | `io.elementary.files $(pwd) &`   | Open the Elementary Files Application in the current folder of the terminal                                                                                                                 |
| `io.elementary.switchboard`    | `io.elementary.switchboard`      | Open the Elementary Settings App                                                                                                                                                            |
| `lsb_release -a`               |                                  | List the Elementary version you have installed                                                                                                                                              |
| `sudo service lightdm restart` |                                  | Restart the desktop service, you will have to login again.                                                                                                                                  |
 

## About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
    <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

## References

https://elementaryos.stackexchange.com/questions/184/how-can-i-reset-keyboard-shortcuts

<p align="right">
  <a href="#">Come back to the top</a>
</p>