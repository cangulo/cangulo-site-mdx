- [Regex CheatSheet](#regex-cheatsheet)
  - [Using regular expressions in the command grep](#using-regular-expressions-in-the-command-grep)
  - [How to test regex in the command line?](#how-to-test-regex-in-the-command-line)
  - [About me](#about-me)

# Regex CheatSheet
## Using regular expressions in the command grep

The command `grep` could also use regexs as following:

```bash
grep [REGEX]                          # Simple Regex
grep -E [REGEX_WITH_SCAPE_CHARACTERS] # Advanced
```

Next are simple ones, they don't require the `-E` option:

| Regex    | Matching                                                                           |
| -------- | ---------------------------------------------------------------------------------- |
| `^WORD`  | Any lines that **starts** with WORD                                                |
| `WORD$"` | Any lines that **ends** with WORD                                                  |
| `W.RD`   | Any lines that contains `W` followed by `{ANY_CHARACTER}` (but only one), and `RD` |
| `W*RD`   | Any lines that contains `W`, followed by zero or more characters, and `RD`         |

Next are more advanced regex expression that needs `-E` option:

| Expression | Matching                                                                     | Example   |
| ---------- | ---------------------------------------------------------------------------- | --------- |
| `{n}`      | Matches the preceding character appearing **exactly *n* times**              | `p\{2}`   |
| `{n,m}`    | Matches the preceding character appearing ***n* but times no more than *m*** | `p\{2,3}` |
| `{n,}`     | Matches the preceding character appearing **at least *n* times**             | `p\{2,}`  |

## How to test regex in the command line?

| Command                       | Remark                                                            |
| ----------------------------- | ----------------------------------------------------------------- |
| `echo "TEXT" \| grep [REGEX]` |                                                                   |
| `cat [FILE] \| grep [REGEX]`  | grep will try to match the `[REGEX]` on each line of the `[FILE]` |


## About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
    <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

<p align="right">
  <a href="#">Come back to the top</a>
</p>