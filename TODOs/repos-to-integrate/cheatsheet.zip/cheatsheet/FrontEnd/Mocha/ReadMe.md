<!-- REF_LINKS:Links -->
<!-- https://github.com/mochajs/mocha-examples/tree/master/packages/programmatic-usage -->

# Execute Mocha Unit Test
In the package json:
```json
"scripts"{
    "utest": "mocha -r ts-node/register src/markdownCodeUpdate/**/*.test.ts"
}	
```
then execute `npm run utest`