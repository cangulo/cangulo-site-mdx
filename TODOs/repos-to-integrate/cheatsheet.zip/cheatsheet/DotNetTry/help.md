dotnet-try:
  Interactive documentation in your browser

Usage:
  dotnet-try [options] [<RootDirectory>] [command]

Arguments:
  <RootDirectory>    Specify the path to the root directory for your documentation

Options:
  --add-package-source <NuGet source>    Specify an additional NuGet package source
  --package <name or .csproj>            Specify a Try .NET package or path to a .csproj to run code samples with
  --package-version <version>            Specify a Try .NET package version to use with the --package option
  --uri <uri>                            Specify a URL or a relative path to a Markdown file
  --enable-preview-features              Enable preview features
  --log-path <dir>                       Enable file logging to the specified directory
  --verbose                              Enable verbose logging to the console
  --port <port>                          Specify the port for dotnet try to listen on
  --version                              Display version information

Commands:
  demo                      Learn how to create Try .NET content with an interactive demo
  verify <RootDirectory>    Verify Markdown files in the target directory and its children.

