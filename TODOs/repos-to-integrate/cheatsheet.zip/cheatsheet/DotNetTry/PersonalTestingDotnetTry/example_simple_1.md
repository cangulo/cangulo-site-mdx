# Dotnet Try Basic Example 1: Simple region execution

## Program.cs
```csharp --editable false --source-file ./Program.cs --region Program.cs --project ./PersonalTesting.csproj
```

## Main Code to be executed: region example_basic_1
```csharp --source-file ./Program.cs --region example_basic_1 --project ./PersonalTesting.csproj
```