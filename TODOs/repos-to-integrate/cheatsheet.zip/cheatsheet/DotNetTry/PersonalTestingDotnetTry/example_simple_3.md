# Dotnet Try Basic Example 3: Execute code before specific region

## Program.cs
```csharp --editable false --source-file ./Program.cs --region Program.cs --project ./PersonalTesting.csproj
```

## Code to be execute first: Useful to modify variables used in the main code

If you want to execute code before an specific region, for example, to alter variables, you should create a new area, locate the code you want to execute and use the next tags:

* `--region` with the region with the code we want to decorate
* `--destination-file` file where the region is located
* `--project` with the .csproj file
* `--hidden` if you want to hide the code
* `--editable false` if you want to display the code (**Don't use true!!!**)

It is not mandatory to locate that new area  before the main region, but I recommend do it.

If you execute the last area, the execution flow will be:
1. Code at the Program.cs
2. Arrive to the region example_basic_3
3. Execute the next area, overwriting the object *testObject_simple* created previously
4. Execute the region definition in the Program.cs

```csharp --editable false --destination-file ./Program.cs --region example_basic_3 --project ./PersonalTesting.csproj
// Next line overwrites testObject_simple object created in program.cs
testObject_simple = new TestClass("Simple Example 3");
```

## Main Code to be executed: region example_basic_3
```csharp --source-file ./Program.cs --region example_basic_3 --project ./PersonalTesting.csproj
```