﻿using System;

namespace PersonalTesting
{
    #region Program.cs
    public class Program
    {
        public static void Main(
            string region = null,
            string session = null,
            string package = null,
            string project = null,
            string[] args = null)
        {
            Console.WriteLine("program.cs: Start");

            switch (region)
            {
                case "example_basic_1":
                    #region example_basic_1
                    Console.WriteLine($"program.cs: Helloworld!");
                    #endregion
                    break;
                case "example_basic_3":
                    var testObject_simple = new TestClass("Program.Main");
                    #region example_basic_3
                    testObject_simple.TestMethod("Program.Main");
                    #endregion
                    break;
                case "advanced_example_1":
                    var testObject_advanced = new TestClass("Program.Main");
                    #region advanced_example_1
                    testObject_advanced.TestMethod("Program.Main");
                    #endregion
                    break;
            }
            Console.WriteLine("program.cs: End");
        }
    }
    #endregion
}