# Dotnet Try Advanced Example 1: Create More advance Context

# Advanced context created
The next lines are a replica of the Program.cs file but only containing an empty region for *advanced_example_1*. By doing that we will hack the execution flow which will be next:

1. Execute the Main defined in the .md file 
2. When the execution arrives to the empty region *advanced_example_1* in the replica, it will jump to its definition in the Program.cs
3. The real definition of *advanced_example_1* will be executed
4. Execution come back to the replica and continue after the empty region 

Please execute to the last area to see that.

```csharp --editable false --destination-file ./Program.cs --project ./PersonalTesting.csproj

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace PersonalTesting
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("advanced_example_1.md: before advanced_example_1 Region");
            // Next line overwrites the testObject_advanced defined in the program.cs 
            var testObject_advanced = new TestClass("advanced_example_1");  
            #region advanced_example_1
            #endregion
            Console.WriteLine("advanced_example_1.md: after advanced_example_1 Region");
        }
    }
}
```

# Main code to be executed: region advanced_example_1
```csharp --source-file ./Program.cs --region advanced_example_1 --project ./PersonalTesting.csproj
```

Please note we keep using the next tags to link our replica to the Main code.

* `--region` with the region with the code we want to decorate
* `--destination-file` file where the region is located
* `--project` with the .csproj file
* `--hidden` if you want to hide the code
* `--editable false` if you want to display the code (**Don't use true!!!**)