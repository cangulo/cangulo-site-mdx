using System;

namespace PersonalTesting
{
    public class TestClass
    {
        private readonly string _privateParam;

        public TestClass(string privateParam)
        {
            _privateParam = privateParam;
        }

        public void TestMethod(string parameter1)
        {
            Console.WriteLine($"TestClass: constructor parameter:  \"{_privateParam}\" method parameter \"{parameter1}\"");
        }
    }
}