# Dotnet Try Basic Example 2: Code Execution before an specific region

## Program.cs
```csharp --editable false --source-file ./Program.cs --region Program.cs --project ./PersonalTesting.csproj
```

## Code to be execute first: Trace data example

If you want to execute code before an specific region, for example, to output data or prepare some conditions, you should create a new area, locate the code you want to execute and use the next tags:

* `--region` with the region with the code we want to decorate
* `--destination-file` file where the region is located
* `--project` with the .csproj file
* `--hidden` if you want to hide the code
* `--editable false` if you want to display the code (**Don't use true!!!**)

It is not mandatory to locate that new area  before the main region, but I recommend do it.

If you execute the last area, the next two will be executed first and after, the main code.

```csharp --editable false --destination-file ./Program.cs --region example_basic_1 --project ./PersonalTesting.csproj
Console.WriteLine($"printed before the region execution 1");
```

```csharp --editable false --destination-file ./Program.cs --region example_basic_1 --project ./PersonalTesting.csproj
Console.WriteLine($"printed before the region execution 2");
```

## Main Code to be executed: region example_basic_1
```csharp --source-file ./Program.cs --region example_basic_1 --project ./PersonalTesting.csproj
```

Please note text:
* It doesn't matter where you put this area in the .md file as long as you add the correct tags
* If you put more than one area, the order of execution is from the top to the bottom