# dotnet try CheatSheet

## Install and update

```console
dotnet tool install --global dotnet-try
dotnet tool update --global dotnet-try
```

## Main Command

```console
dotnet-try [options] [RootDirectory] [command]
```

## Command

| Command  | Purpose                                |
| -------- | -------------------------------------- |
| `verify` | compiler for documentation             |
| `demo`   | launches getting started documentation |

## Main use
| Command             | Purpose                                               |
| ------------------- | ----------------------------------------------------- |
| `dotnet-try`        | open the interactive documentation in the web browser |
| `dotnet-try verify` | compile the documentation                             |

## Options


| Option                                | Purpose                                                                    |
| ------------------------------------- | -------------------------------------------------------------------------- |
| `--project`                           | enables you to point to a specific file.                                   |
| `--region`                            | lets you specify the block of code that you want to display in the editor. |
| `--add-package-source <NuGet source>` | Specify an additional NuGet package source                                 |
| `--package <name or .csproj>`         | Specify a Try .NET package or path to a .csproj to run code samples with   |
| `--package-version <version>`         | Specify a Try .NET package version to use with the --package option        |
| `--uri <uri>`                         | Specify a URL or a relative path to a Markdown file                        |
| `--enable-preview-features`           | Enable preview features                                                    |
| `--log-path <dir>`                    | Enable file logging to the specified directory                             |
| `--verbose`                           | Enable verbose logging to the console                                      |
| `--port <port>`                       | Specify the port for dotnet try to listen on                               |
| `--version`                           | Display version information                                                |


## Markdown example: code fence

````markdown
```csharp --source-file ./Snippets/Program.cs --project ./Snippets/Snippets.csproj --region run1
```
````

## Markdown options

| Option                  | Purpose                                                                    |
| ----------------------- | -------------------------------------------------------------------------- |
| `--source-file`         | file where the region tag is located.                                      |
| `--project`             | enables you to point to a specific **.csproj** file.                       |
| `--region`              | lets you specify the block of code that you want to display in the editor. |
| `--session`             | compiler session associated.                                               |
| `--editable false|true` | set the code as editable.By default is true.                               |
| `--hidden`              | set the code as hidden. However, the code is executed.                     |

## Basic Main Model

Use next nuggets:
* System.CommandLine.DragonFruit
* System.CommandLine.Experimental

.csproj modification
```xml
  <ItemGroup>
    <PackageReference Include="System.CommandLine.DragonFruit" Version="0.3.0-alpha.19317.1" />
    <PackageReference Include="System.CommandLine.Experimental" Version="0.3.0-alpha.19317.1" />
  </ItemGroup>
```


Follow next model:
```csharp
using System;

namespace PersonalTesting
{
    public class Program
    {
        public static void Main(
            string region = null,
            string session = null,
            string package = null,
            string project = null,
            string[] args = null)
        {
            switch (region)
            {
                case "simple_example_1":
                    #region simple_example_1
                    // code simple_example_1
                    #endregion
                    break;
                case "simple_example_2":
                    var testObject_simple = new TestClass("Program.Main");
                    #region simple_example_2
                    // code simple_example_2
                    #endregion
                    break;
            }
        }
    }
}
```
## Create context for a code execution

### Simple Context

If you want to execute code before an specific region, for example, to output data or prepare some conditions, you should create a new area, locate the code you want to execute and use the next tags:

* `--region` with the region with the code we want to decorate
* `--destination-file` file where the region is located
* `--project` with the .csproj file
* `--hidden` if you want to hide the code
* `--editable false` if you want to display the code (**Don't use true!!!**)

It is not mandatory to locate that new area  before the main region, but I recommend do it.

#### Example 1

````markdown
<!-- Code to be execute first: useful to output data -->
```csharp --hidden --destination-file ./Program.cs --region simple_example_1 --project ./PersonalTesting.csproj
Console.WriteLine($"printed before the region execution");
```

<!-- Main Code  -->
```csharp --source-file ./Program.cs --region simple_example_1 --project ./PersonalTesting.csproj
```
````

#### Example 2

````markdown
<!-- Code to be execute first: Useful to modify variables used in the main code -->
```csharp --editable false --destination-file ./Program.cs --region simple_example_2 --project ./PersonalTesting.csproj
// Next line overwrites testObject_simple object created in program.cs
testObject_simple = new TestClass("Simple Example 3");
```

<!-- Main Code  -->
```csharp --source-file ./Program.cs --region simple_example_2 --project ./PersonalTesting.csproj
```
````

### Advanced Context

In order to have much more context with variables and classes you can create a new Main before the main code. Follow the next steps:

1. Before the main code (not mandatory), create an area with the follow tags:

* `--region` with the region with the code we want to decorate
* `--destination-file` file where the region is located
* `--project` with the .csproj file
* `--hidden` if you want to hide the code
* `--editable false` if you want to hide to be displayed (**Don't use true!!!**)

2. Create a replica of the Program.cs file but removing all the code not related with the main one to be executed. Follow the bottom example.

3. Create an empty region with the same name as the one in Program.cs

```cs --editable false --destination-file ./Program.cs --project ./PersonalTesting.csproj

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace PersonalTesting
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("advanced_example_1.md: before advanced_example_1 Region");
            // Next line overwrites the testObject_advanced defined in the program.cs 
            var testObject_advanced = new TestClass("advanced_example_1");  
            #region advanced_example_1
            // When the execution arrives to this point, it will jump to the region definition in the Program.cs
            #endregion
            Console.WriteLine("advanced_example_1.md: after advanced_example_1 Region");
        }
    }
}
```

```csharp --source-file ./Program.cs --region advanced_example_1 --project ./PersonalTesting.csproj
```