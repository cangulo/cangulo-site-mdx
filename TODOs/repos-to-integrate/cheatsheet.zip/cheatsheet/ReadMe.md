# This is my personal Cheatsheet Repository

Those are the most complete cheatsheets I have are:

* [Bash Cheatsheet](https://carlosangulo.es/cheatsheet/bash/): I'm proud of this one! I am adding more commands as I learn :grin:
* [Elementary](./ElementaryCheatSheet/ReadMe.md): Those are the basic command of default Elementary Apps.
* [Elementary Personal Config](./ElementaryCheatSheet/PersonalConfigCheatSheet/ReadMe.md): This is my elementary configuration, you can fine an example of how to define custom app launcher as well as keyboard shortcuts, always focus in be more productive :smiley:	

# About me

I'm a software engineer with experience in .NET Framework, .NET Core and Angular, I love challenges, learning and share knowledge. Feel free to contact me via LinkedIn.

<p align="center">
      <img src="https://raw.githubusercontent.com/cangulo/cangulo.github.io/dev/src/markdown-pages/aboutme/profile_picture.png">
</p>

*Per aspera ad astra.*

LinkedIn   - [Carlos Angulo Mascarell](https://www.linkedin.com/in/angulomascarell) \
Twitter   - [@AnguloMascarell](https://twitter.com/angulomascarell)

<p align="right">
    <a href="#">Come back to the top</a>
</p>

<!-- TODO: Create Script to list the markdown files with the description associated, in that you will save adding any new file here   -->