<!-- TODO:Create a list of VS Code tips as -->

* List all extensions
* Export extensions 
* Install extensions via command line
* Check for tips and tricks in google

[Configure Quick Suggestions in VSCode]([https://link](https://stackoverflow.com/questions/43639841/how-to-set-markdown-snippet-trigger-automatically))