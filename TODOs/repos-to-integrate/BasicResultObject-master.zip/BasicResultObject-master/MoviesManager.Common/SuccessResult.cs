﻿namespace MoviesManager.Common
{
    public class SuccessResult : Result
    {
        public SuccessResult() : base(true)
        {

        }
    }

    public class SuccessResult<T> : Result
    {
        public T Value { get; }
        public SuccessResult(T value) : base(true)
        {
            this.Value = value;
        }
    }
}
