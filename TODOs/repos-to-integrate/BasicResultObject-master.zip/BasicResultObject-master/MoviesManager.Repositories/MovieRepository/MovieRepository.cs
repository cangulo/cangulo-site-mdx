﻿using MoviesManager.Common;
using MoviesManager.Model.DB;
using System.Collections.Generic;

namespace MoviesManager.Repositories.MovieRepository
{
    public class MovieRepository : IMovieRepository
    {
        public Result GetMovies()
        {
            bool queryValidation = true;
            if (queryValidation)
            {
                return new SuccessResult<List<Movie>>(new List<Movie>
                {
                    new Movie()
                    {
                        Title = "Star Wars: Episode IV - A New Hope",
                        Director = "George Lucas",
                        Year = 1977
                    },
                                    new Movie()
                    {
                        Title = "Star Wars: Episode V - The Empire Strikes Back",
                        Director = "George Lucas",
                        Year = 1980
                    }
                });
            }
            else
            {
                return new FailedResult("Error in the query", "1", "Repository");
            }
        }

        public Result RegisterMovie(Movie movie)
        {
            bool repositoryValidation = true;
            if (repositoryValidation)
            {
                return new SuccessResult();
            }
            else
            {
                return new FailedResult("Director is not valid", "1", "Repository");
            }
        }
    }
}
