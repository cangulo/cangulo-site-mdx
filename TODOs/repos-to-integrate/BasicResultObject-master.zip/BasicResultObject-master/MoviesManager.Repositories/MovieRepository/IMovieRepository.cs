﻿using MoviesManager.Common;
using MoviesManager.Model.DB;

namespace MoviesManager.Repositories.MovieRepository
{
    public interface IMovieRepository
    {
        Result GetMovies();

        Result RegisterMovie(Movie movie);
    }
}
