﻿using MoviesManager.Model.DB;
using System.Collections.Generic;

namespace MoviesManager.Services.MovieService
{
    public interface IMovieService
    {
        List<Movie> GetMovies();

        void RegisterMovie(Movie movie);
    }
}
