﻿using MoviesManager.Model.DB;
using MoviesManager.Repositories.MovieRepository;
using System.Collections.Generic;

namespace MoviesManager.Services.MovieService
{
    public class MovieService : IMovieService
    {
        private IMovieRepository _movieRepo;
        public MovieService(IMovieRepository movieRepo)
        {
            this._movieRepo = movieRepo;
        }
        public List<Movie> GetMovies()
        {
            return this._movieRepo.GetMovies();
        }

        public void RegisterMovie(Movie movie)
        {
            this._movieRepo.RegisterMovie(movie);
        }
    }
}
