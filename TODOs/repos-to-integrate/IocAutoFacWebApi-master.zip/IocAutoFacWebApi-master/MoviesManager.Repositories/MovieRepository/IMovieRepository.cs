﻿using MoviesManager.Model.DB;
using System.Collections.Generic;

namespace MoviesManager.Repositories.MovieRepository
{
    public interface IMovieRepository
    {
        List<Movie> GetMovies();

        void RegisterMovie(Movie movier);
    }
}
