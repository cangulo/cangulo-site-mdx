﻿using MoviesManager.Model.DB;
using System.Collections.Generic;

namespace MoviesManager.Repositories.MovieRepository
{
    public class MovieRepository : IMovieRepository
    {
        public List<Movie> GetMovies()
        {
            return new List<Movie>
            {
                new Movie()
                {
                    Title = "Star Wars: Episode IV - A New Hope",
                    Director = "George Lucas",
                    Year = 1977
                },
                                new Movie()
                {
                    Title = "Star Wars: Episode V - The Empire Strikes Back",
                    Director = "George Lucas",
                    Year = 1980
                }
            };
        }

        public void RegisterMovie(Movie movier)
        {
            // Stuff to register a movie
        }
    }
}
