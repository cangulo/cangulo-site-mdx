﻿using Autofac;
using Autofac.Integration.WebApi;
using MoviesManager.Repositories.MovieRepository;
using MoviesManager.Services.MovieService;
using System.Reflection;
using System.Web.Http;

namespace MoviesManager.App_Start
{
    public class IoCConfig
    {
        public static void Configure()
        {
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            builder.RegisterType<MovieService>().As<IMovieService>();
            builder.RegisterType<MovieRepository>().As<IMovieRepository>();

            var container = builder.Build();
            var resolver = new AutofacWebApiDependencyResolver(container);
            GlobalConfiguration.Configuration.DependencyResolver = resolver;
        }
    }
}