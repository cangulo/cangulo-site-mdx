﻿using MoviesManager.Model.DB;
using MoviesManager.Services.MovieService;
using System.Collections.Generic;
using System.Web.Http;

namespace MoviesManager.Controllers
{
    public class MoviesController : ApiController
    {
        private readonly IMovieService _movieService;
        public MoviesController(IMovieService movieService)
        {
            this._movieService = movieService;
        }
        public IEnumerable<Movie> Get()
        {
            return this._movieService.GetMovies();
        }

        [HttpPost]
        public IHttpActionResult PostMovie([FromBody]Movie movie)
        {
            this._movieService.RegisterMovie(movie);
            return Ok();
        }


    }
}
